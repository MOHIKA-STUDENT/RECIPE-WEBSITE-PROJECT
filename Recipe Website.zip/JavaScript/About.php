<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Foodielight</title>
    <link rel="stylesheet" href="signlog.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">


</head>

<body>
    <div id="logo">
        SmartRecipe
    </div>
    <div id="nav">
        <ul>
            <!-- <li><a class="link" href="Sign up.php"><i id="icon" class="fa-solid fa-circle-user"></i>Sign Up/Login</a>
            </li> -->
            <li><a class="link" href="Privacy.php">Privacy Policy</a></li>
            <li><a class="link" href="login.php">Home</a></li>
        </ul>
    </div>

    <div id="about-content">
        <div class="content">
            <h1>About Us</h1>
            <p>Welcome to Foodielight!!, your go-to platform for discovering and sharing delicious recipes! We are
                passionate
                about food and cooking, and we created this platform to bring food enthusiasts together.</p>
            <br>
            <p>Our platform allows users to explore a wide variety of recipes uploaded by our community of users.
                Whether
                you're looking for quick and easy weeknight dinners, indulgent desserts, or healthy snacks, you'll find
                it
                all here on Foodielight.</p>
            <br>
            <p>In addition to browsing recipes, users can also upload their own recipes to share with others. We believe
                in
                the power of community and sharing knowledge, and we're excited to see what delicious creations our
                users
                come up with.</p>
            <br>
            <p>So whether you're a seasoned chef or a novice cook, we invite you to join our community and embark on a
                culinary adventure with Foodielight!</p>
            <br>
            Email:
            foodielight@gmail.com
            <br>
            Mobile No. :
            9803826383

        </div>
    </div>
</body>

</html>